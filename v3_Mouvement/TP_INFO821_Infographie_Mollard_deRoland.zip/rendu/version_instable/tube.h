#ifndef TESTS_H
#define TESTS_H

half_edge creerTubeEntier(int nbPoints, repere Rep, const point3d D, const point3d A, double R, int precision);
half_edge creerVaisseau();

#endif
