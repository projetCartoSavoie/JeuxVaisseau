 _________________________________
| 																|
| Rémi Mollard  									|
| Céline de Roland								|
|																	|
| TP d'infographie, M1 STIC ISC		|
|_________________________________|

Nous rendons deux versions du tp (voir dans les sous dossiers correspondants) :

	La version stable fonctionne sans problème et se comporte comme attendu
	La version instable correspond au point auquel nous nous sommes arrêtés, avec les dernières fonctionnalités implémentées mais ne fonctionnant pas comme nous l'attendons.
	

