#ifndef LEVAISSEAU_H
#define LEVAISSEAU_H

half_edge creerVaisseau(double ri, double rj, double rv, double ti, double tj, const point3d C, const vecteur3d I, const vecteur3d J, const vecteur3d V);

#endif